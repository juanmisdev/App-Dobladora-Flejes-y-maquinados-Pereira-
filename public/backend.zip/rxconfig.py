import reflex as rx

config = rx.Config(
    app_name="App Dobladora",
    api_url= 'https://api.vercel.com:8000',
)
